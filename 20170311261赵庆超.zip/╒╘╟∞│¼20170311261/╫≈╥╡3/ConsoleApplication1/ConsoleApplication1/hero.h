#include <iostream>
using namespace std;
class Hero
{
	public:
		Hero();
		Hero(int y1);
		~Hero();
		
	private:
		int x1;
		int x2;
		int x3;
		int blood1;
		int blood2;
};