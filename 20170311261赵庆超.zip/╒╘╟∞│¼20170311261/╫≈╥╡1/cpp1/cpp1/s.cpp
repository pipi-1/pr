#include <iostream>
#include <conio.h>
using namespace std;
int main()
{
	cout<<" **********          **"<<'\n';
	cout<<" **********         ***"<<'\n';
	cout<<" **                  **"<<'\n';
	cout<<" **                  **"<<'\n';
	cout<<" **********          **"<<'\n';
	cout<<" **********          **"<<'\n';
	cout<<" **********          **"<<'\n';
	cout<<" **      **          **"<<'\n';
	cout<<" **********          **"<<'\n';
	cout<<" **********        ******"<<'\n';
	getch();
	return 0;
}