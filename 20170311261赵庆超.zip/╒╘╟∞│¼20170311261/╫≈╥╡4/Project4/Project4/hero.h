#include <iostream>
using namespace std;
class Hero
{
public:
	Hero();
	int skillwork(int a)
	{
		x = a;
		return x;
	};
	int blood1(int b) {
		y = b;
		return y;
	};
	int blood2(int c) {

		z = c;
		return z;
	};
	~Hero();

private:
	int x;
	int y;
	int z;
	int w;
	int q;
};
