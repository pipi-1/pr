#include<iostream>
#include"hero.h"
using namespace std;
Hero::Hero() {};
Hero::~Hero() {};
int main()
{
	int skill, i,j,m,n,o,k;
	Hero Jinjin;
	Hero Luban;
	Hero Zhuangzhou;
	cout << "ѡ����ļ��ܣ�����1��2" << endl;
	cin >> skill;
	if (skill = 1) {
		m=Jinjin.skillwork(10);
	}
	else {
		m=Jinjin.skillwork(20);
	}
	n=Luban.blood1(50);
	o=Zhuangzhou.blood2(60);
	cout << "��ʼѪ��50��60" << endl;
	i = n-m/2;
	j = o-m/2;
	cout <<"ʣ��"<< i << " " << j << endl;
	cin>> k;
	return 0;
}