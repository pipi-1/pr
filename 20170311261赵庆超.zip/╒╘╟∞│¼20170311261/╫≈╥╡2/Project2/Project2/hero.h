#include <iostream>
using namespace std;
class Hero
{
public:
	int JSkill(int x1, int x2, int x3)
	{
		skill1 = x1;
		skill2 = x2;
		skill3 = x3;
		return 0;
	}
	int getskill() 
	
	{
		int renshu = 0;
		blood = 50;
		die = blood - skill1 - skill2 - skill3;
		while (renshu  < 5)
		{
			renshu++;
			cout << "��ɱһ��" <<renshu<<endl;
		};
		return 0;
	}

private:
	int skill1;
	int skill2;
	int skill3;
	int blood;
	int die;
	int renshu;
};