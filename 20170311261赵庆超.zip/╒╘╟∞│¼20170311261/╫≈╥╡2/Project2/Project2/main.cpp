#include<iostream>
#include"hero.h"
using namespace std;
inline int skilla(int a)
{
	return 0;
}
int main()
{
	int k;
	Hero Jinjin;

	Jinjin.JSkill(10, 20, 30);
		cout << "��������1+a+2+2+3" << endl;
		cout << "�Է�Ӣ��Ѫ��50" << endl;
		cout << Jinjin.getskill() << endl;
		cin >> k;
	return 0;

}